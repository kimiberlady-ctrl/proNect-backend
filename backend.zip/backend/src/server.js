const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
const authRoutes = require('./routes/authRoutes');
const offresRoutes = require('./routes/offresRoutes');
const candidaturesRoutes = require('./routes/candidaturesRoutes');  
const profilsRoutes = require('./routes/profilsRoutes');
const adminRoutes = require('./routes/adminRoutes');

app.use('/api/auth', authRoutes);
app.use('/api/offres', offresRoutes);
app.use('/api/candidatures', candidaturesRoutes);  
app.use('/api/profils', profilsRoutes);
app.use('/api/admin', adminRoutes);


// Route de test
app.get('/', (req, res) => {
  res.json({ message: 'Bienvenue sur l\'API ProNect !' });
});

// Démarrage du serveur
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`);
});