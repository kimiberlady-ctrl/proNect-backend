const express = require('express');
const router = express.Router();
const offresController = require('../controllers/offresController');
const authMiddleware = require('../middleware/auth');

// Routes publiques
router.get('/', offresController.getAllOffres);
router.get('/:id', offresController.getOffreById);

// Routes protégées (entreprises uniquement)
router.post('/', authMiddleware, offresController.createOffre);
router.get('/mes-offres/liste', authMiddleware, offresController.getOffresEntreprise);
router.put('/:id', authMiddleware, offresController.updateOffre);
router.delete('/:id', authMiddleware, offresController.deleteOffre);

module.exports = router;