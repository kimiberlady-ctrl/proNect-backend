const express = require('express');
const router = express.Router();
const profilsController = require('../controllers/profilsController');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

// Routes étudiants
router.get('/etudiant', profilsController.getProfilEtudiant);
router.put('/etudiant', profilsController.updateProfilEtudiant);

// Routes entreprises
router.get('/entreprise', profilsController.getProfilEntreprise);
router.put('/entreprise', profilsController.updateProfilEntreprise);

module.exports = router;