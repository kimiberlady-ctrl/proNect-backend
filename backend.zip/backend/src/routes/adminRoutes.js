const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const authMiddleware = require('../middleware/auth');

// Toutes les routes nécessitent authentification admin
router.use(authMiddleware);

router.get('/users', adminController.getAllUsers);
router.get('/offres', adminController.getAllOffres);
router.get('/candidatures', adminController.getAllCandidatures);
router.delete('/users/:id', adminController.deleteUser);
router.delete('/offres/:id', adminController.deleteOffre);

module.exports = router;