const express = require('express');
const router = express.Router();
const candidaturesController = require('../controllers/candidaturesController');
const authMiddleware = require('../middleware/auth');

// Toutes les routes nécessitent une authentification
router.use(authMiddleware);

// Routes étudiants
router.post('/', candidaturesController.postuler);
router.get('/mes-candidatures', candidaturesController.getMesCandidatures);

// Routes entreprises
router.get('/offre/:offreId', candidaturesController.getCandidaturesOffre);
router.put('/:id/statut', candidaturesController.updateStatutCandidature);

module.exports = router;