const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');

// Inscription
exports.register = async (req, res) => {
  try {
    const { 
      email, password, nom, prenom, type_compte, telephone,
      // Champs étudiants
      etablissement, niveau_etude, domaine_etude,
      // Champs entreprises
      nom_entreprise, secteur
    } = req.body;

    // Validation basique
    if (!email || !password || !nom || !prenom || !type_compte) {
      return res.status(400).json({ error: 'Tous les champs obligatoires doivent être remplis.' });
    }

    // Vérifier si l'email existe déjà
    const [existingUser] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
    
    if (existingUser.length > 0) {
      return res.status(400).json({ error: 'Cet email est déjà utilisé.' });
    }

    // Hasher le mot de passe
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insérer l'utilisateur
    const [result] = await db.query(
      'INSERT INTO users (email, password, nom, prenom, type_compte, telephone) VALUES (?, ?, ?, ?, ?, ?)',
      [email, hashedPassword, nom, prenom, type_compte, telephone]
    );

    const userId = result.insertId;

    // Créer le profil selon le type de compte
    if (type_compte === 'etudiant') {
      await db.query(
        'INSERT INTO profils_etudiants (user_id, etablissement, niveau_etude, domaine_etude) VALUES (?, ?, ?, ?)',
        [userId, etablissement || '', niveau_etude || '', domaine_etude || '']
      );
    } else if (type_compte === 'entreprise') {
      await db.query(
        'INSERT INTO profils_entreprises (user_id, nom_entreprise, secteur) VALUES (?, ?, ?)',
        [userId, nom_entreprise || '', secteur || '']
      );
    }

    // Générer un token JWT
    const token = jwt.sign(
      { id: userId, email, type_compte },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'Inscription réussie !',
      token,
      user: {
        id: userId,
        email,
        nom,
        prenom,
        type_compte
      }
    });

  } catch (error) {
    console.error('Erreur lors de l\'inscription:', error);
    res.status(500).json({ error: 'Erreur serveur lors de l\'inscription.' });
  }
};

// Connexion
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validation
    if (!email || !password) {
      return res.status(400).json({ error: 'Email et mot de passe requis.' });
    }

    // Chercher l'utilisateur
    const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);

    if (users.length === 0) {
      return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });
    }

    const user = users[0];

    // Vérifier le mot de passe
    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });
    }

    // Générer un token
    const token = jwt.sign(
      { id: user.id, email: user.email, type_compte: user.type_compte },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Connexion réussie !',
      token,
      user: {
        id: user.id,
        email: user.email,
        nom: user.nom,
        prenom: user.prenom,
        type_compte: user.type_compte,
        telephone: user.telephone
      }
    });

  } catch (error) {
    console.error('Erreur lors de la connexion:', error);
    res.status(500).json({ error: 'Erreur serveur lors de la connexion.' });
  }
};

// Récupérer le profil de l'utilisateur connecté
exports.getProfile = async (req, res) => {
  try {
    const userId = req.user.id;

    const [users] = await db.query('SELECT id, email, nom, prenom, type_compte, telephone FROM users WHERE id = ?', [userId]);

    if (users.length === 0) {
      return res.status(404).json({ error: 'Utilisateur non trouvé.' });
    }

    res.json({ user: users[0] });

  } catch (error) {
    console.error('Erreur lors de la récupération du profil:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};