const db = require('../config/database');

// Créer une offre (réservé aux entreprises)
exports.createOffre = async (req, res) => {
  try {
    const { titre, description, domaine, type_stage, duree, remuneration, ville, date_debut, date_limite } = req.body;
    const entrepriseId = req.user.id;

    // Vérifier que l'utilisateur est une entreprise
    if (req.user.type_compte !== 'entreprise') {
      return res.status(403).json({ error: 'Seules les entreprises peuvent créer des offres.' });
    }

    // Validation
    if (!titre || !description || !domaine || !type_stage || !ville) {
      return res.status(400).json({ error: 'Tous les champs obligatoires doivent être remplis.' });
    }

    const [result] = await db.query(
      `INSERT INTO offres (entreprise_id, titre, description, domaine, type_stage, duree, remuneration, ville, date_debut, date_limite) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [entrepriseId, titre, description, domaine, type_stage, duree, remuneration, ville, date_debut, date_limite]
    );

    res.status(201).json({
      message: 'Offre créée avec succès !',
      offre: {
        id: result.insertId,
        titre,
        domaine,
        ville
      }
    });

  } catch (error) {
    console.error('Erreur lors de la création de l\'offre:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer toutes les offres actives
exports.getAllOffres = async (req, res) => {
  try {
    const { domaine, ville, type_stage, search } = req.query;

    let query = `
      SELECT o.*, u.nom as entreprise_nom, pe.nom_entreprise
      FROM offres o
      JOIN users u ON o.entreprise_id = u.id
      LEFT JOIN profils_entreprises pe ON u.id = pe.user_id
      WHERE o.statut = 'active'
    `;

    const params = [];

    // Filtres
    if (domaine) {
      query += ' AND o.domaine = ?';
      params.push(domaine);
    }

    if (ville) {
      query += ' AND o.ville = ?';
      params.push(ville);
    }

    if (type_stage) {
      query += ' AND o.type_stage = ?';
      params.push(type_stage);
    }

    if (search) {
      query += ' AND (o.titre LIKE ? OR o.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY o.date_publication DESC';

    const [offres] = await db.query(query, params);

    res.json({ offres });

  } catch (error) {
    console.error('Erreur lors de la récupération des offres:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer une offre par ID
exports.getOffreById = async (req, res) => {
  try {
    const offreId = req.params.id;

    const [offres] = await db.query(
      `SELECT o.*, u.nom as entreprise_nom, u.email as entreprise_email, u.telephone as entreprise_telephone,
              pe.nom_entreprise, pe.secteur, pe.description as entreprise_description, pe.site_web
       FROM offres o
       JOIN users u ON o.entreprise_id = u.id
       LEFT JOIN profils_entreprises pe ON u.id = pe.user_id
       WHERE o.id = ?`,
      [offreId]
    );

    if (offres.length === 0) {
      return res.status(404).json({ error: 'Offre non trouvée.' });
    }

    res.json({ offre: offres[0] });

  } catch (error) {
    console.error('Erreur lors de la récupération de l\'offre:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer les offres d'une entreprise
exports.getOffresEntreprise = async (req, res) => {
  try {
    const entrepriseId = req.user.id;

    if (req.user.type_compte !== 'entreprise') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const [offres] = await db.query(
      'SELECT * FROM offres WHERE entreprise_id = ? ORDER BY date_publication DESC',
      [entrepriseId]
    );

    res.json({ offres });

  } catch (error) {
    console.error('Erreur lors de la récupération des offres:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Mettre à jour une offre
exports.updateOffre = async (req, res) => {
  try {
    const offreId = req.params.id;
    const entrepriseId = req.user.id;
    const { titre, description, domaine, type_stage, duree, remuneration, ville, date_debut, date_limite, statut } = req.body;

    // Vérifier que l'offre appartient à l'entreprise
    const [offres] = await db.query('SELECT * FROM offres WHERE id = ? AND entreprise_id = ?', [offreId, entrepriseId]);

    if (offres.length === 0) {
      return res.status(404).json({ error: 'Offre non trouvée ou vous n\'avez pas les droits.' });
    }

    await db.query(
      `UPDATE offres SET titre = ?, description = ?, domaine = ?, type_stage = ?, duree = ?, 
       remuneration = ?, ville = ?, date_debut = ?, date_limite = ?, statut = ?
       WHERE id = ?`,
      [titre, description, domaine, type_stage, duree, remuneration, ville, date_debut, date_limite, statut, offreId]
    );

    res.json({ message: 'Offre mise à jour avec succès !' });

  } catch (error) {
    console.error('Erreur lors de la mise à jour:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Supprimer une offre
exports.deleteOffre = async (req, res) => {
  try {
    const offreId = req.params.id;
    const entrepriseId = req.user.id;

    const [offres] = await db.query('SELECT * FROM offres WHERE id = ? AND entreprise_id = ?', [offreId, entrepriseId]);

    if (offres.length === 0) {
      return res.status(404).json({ error: 'Offre non trouvée ou vous n\'avez pas les droits.' });
    }

    await db.query('DELETE FROM offres WHERE id = ?', [offreId]);

    res.json({ message: 'Offre supprimée avec succès !' });

  } catch (error) {
    console.error('Erreur lors de la suppression:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};