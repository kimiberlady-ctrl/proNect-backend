const db = require('../config/database');

// Récupérer le profil étudiant
exports.getProfilEtudiant = async (req, res) => {
  try {
    const userId = req.user.id;

    if (req.user.type_compte !== 'etudiant') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const [profils] = await db.query(
      'SELECT * FROM profils_etudiants WHERE user_id = ?',
      [userId]
    );

    if (profils.length === 0) {
      return res.json({ profil: null });
    }

    res.json({ profil: profils[0] });

  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Mettre à jour le profil étudiant
exports.updateProfilEtudiant = async (req, res) => {
  try {
    const userId = req.user.id;
    const { etablissement, niveau_etude, domaine_etude, cv_url, bio, competences } = req.body;

    if (req.user.type_compte !== 'etudiant') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    await db.query(
      `UPDATE profils_etudiants 
       SET etablissement = ?, niveau_etude = ?, domaine_etude = ?, cv_url = ?, bio = ?, competences = ?
       WHERE user_id = ?`,
      [etablissement, niveau_etude, domaine_etude, cv_url, bio, competences, userId]
    );

    res.json({ message: 'Profil mis à jour avec succès !' });

  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer le profil entreprise
exports.getProfilEntreprise = async (req, res) => {
  try {
    const userId = req.user.id;

    if (req.user.type_compte !== 'entreprise') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const [profils] = await db.query(
      'SELECT * FROM profils_entreprises WHERE user_id = ?',
      [userId]
    );

    if (profils.length === 0) {
      return res.json({ profil: null });
    }

    res.json({ profil: profils[0] });

  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Mettre à jour le profil entreprise
exports.updateProfilEntreprise = async (req, res) => {
  try {
    const userId = req.user.id;
    const { nom_entreprise, secteur, taille, adresse, site_web, description } = req.body;

    if (req.user.type_compte !== 'entreprise') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    await db.query(
      `UPDATE profils_entreprises 
       SET nom_entreprise = ?, secteur = ?, taille = ?, adresse = ?, site_web = ?, description = ?
       WHERE user_id = ?`,
      [nom_entreprise, secteur, taille, adresse, site_web, description, userId]
    );

    res.json({ message: 'Profil mis à jour avec succès !' });

  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};