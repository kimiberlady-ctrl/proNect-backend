const db = require('../config/database');

// Récupérer tous les utilisateurs
exports.getAllUsers = async (req, res) => {
  try {
    if (req.user.type_compte !== 'admin') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const [users] = await db.query(
      'SELECT id, email, nom, prenom, type_compte, telephone, date_creation FROM users ORDER BY date_creation DESC'
    );

    res.json({ users });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer toutes les offres
exports.getAllOffres = async (req, res) => {
  try {
    if (req.user.type_compte !== 'admin') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const [offres] = await db.query(
      'SELECT * FROM offres ORDER BY date_publication DESC'
    );

    res.json({ offres });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer toutes les candidatures
exports.getAllCandidatures = async (req, res) => {
  try {
    if (req.user.type_compte !== 'admin') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const [candidatures] = await db.query(
      'SELECT * FROM candidatures ORDER BY date_candidature DESC'
    );

    res.json({ candidatures });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Supprimer un utilisateur
exports.deleteUser = async (req, res) => {
  try {
    if (req.user.type_compte !== 'admin') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const userId = req.params.id;

    // Ne pas permettre la suppression d'un admin
    const [users] = await db.query('SELECT type_compte FROM users WHERE id = ?', [userId]);
    if (users.length > 0 && users[0].type_compte === 'admin') {
      return res.status(403).json({ error: 'Impossible de supprimer un administrateur.' });
    }

    await db.query('DELETE FROM users WHERE id = ?', [userId]);

    res.json({ message: 'Utilisateur supprimé avec succès.' });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Supprimer une offre
exports.deleteOffre = async (req, res) => {
  try {
    if (req.user.type_compte !== 'admin') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const offreId = req.params.id;

    await db.query('DELETE FROM offres WHERE id = ?', [offreId]);

    res.json({ message: 'Offre supprimée avec succès.' });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};