const db = require('../config/database');

// Postuler à une offre (étudiants uniquement)
exports.postuler = async (req, res) => {
  try {
    const { offre_id, lettre_motivation, cv_url } = req.body;
    const etudiantId = req.user.id;

    // Vérifier que l'utilisateur est un étudiant
    if (req.user.type_compte !== 'etudiant') {
      return res.status(403).json({ error: 'Seuls les étudiants peuvent postuler.' });
    }

    // Vérifier que l'offre existe et est active
    const [offres] = await db.query('SELECT * FROM offres WHERE id = ? AND statut = "active"', [offre_id]);

    if (offres.length === 0) {
      return res.status(404).json({ error: 'Offre non trouvée ou non disponible.' });
    }

    // Vérifier si l'étudiant a déjà postulé
    const [existing] = await db.query(
      'SELECT * FROM candidatures WHERE offre_id = ? AND etudiant_id = ?',
      [offre_id, etudiantId]
    );

    if (existing.length > 0) {
      return res.status(400).json({ error: 'Vous avez déjà postulé à cette offre.' });
    }

    // Créer la candidature
    const [result] = await db.query(
      'INSERT INTO candidatures (offre_id, etudiant_id, lettre_motivation, cv_url) VALUES (?, ?, ?, ?)',
      [offre_id, etudiantId, lettre_motivation, cv_url]
    );

    res.status(201).json({
      message: 'Candidature envoyée avec succès !',
      candidature: {
        id: result.insertId,
        offre_id,
        statut: 'en_attente'
      }
    });

  } catch (error) {
    console.error('Erreur lors de la candidature:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer les candidatures d'un étudiant
exports.getMesCandidatures = async (req, res) => {
  try {
    const etudiantId = req.user.id;

    if (req.user.type_compte !== 'etudiant') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    const [candidatures] = await db.query(
      `SELECT c.*, o.titre, o.domaine, o.ville, o.type_stage, 
              u.nom as entreprise_nom, pe.nom_entreprise
       FROM candidatures c
       JOIN offres o ON c.offre_id = o.id
       JOIN users u ON o.entreprise_id = u.id
       LEFT JOIN profils_entreprises pe ON u.id = pe.user_id
       WHERE c.etudiant_id = ?
       ORDER BY c.date_candidature DESC`,
      [etudiantId]
    );

    res.json({ candidatures });

  } catch (error) {
    console.error('Erreur lors de la récupération des candidatures:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Récupérer les candidatures pour une offre (entreprises uniquement)
exports.getCandidaturesOffre = async (req, res) => {
  try {
    const offreId = req.params.offreId;
    const entrepriseId = req.user.id;

    if (req.user.type_compte !== 'entreprise') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    // Vérifier que l'offre appartient à l'entreprise
    const [offres] = await db.query('SELECT * FROM offres WHERE id = ? AND entreprise_id = ?', [offreId, entrepriseId]);

    if (offres.length === 0) {
      return res.status(404).json({ error: 'Offre non trouvée ou vous n\'avez pas les droits.' });
    }

    const [candidatures] = await db.query(
      `SELECT c.*, u.nom, u.prenom, u.email, u.telephone,
              pe.etablissement, pe.niveau_etude, pe.domaine_etude, pe.cv_url as profil_cv
       FROM candidatures c
       JOIN users u ON c.etudiant_id = u.id
       LEFT JOIN profils_etudiants pe ON u.id = pe.user_id
       WHERE c.offre_id = ?
       ORDER BY c.date_candidature DESC`,
      [offreId]
    );

    res.json({ candidatures });

  } catch (error) {
    console.error('Erreur lors de la récupération des candidatures:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};

// Mettre à jour le statut d'une candidature (entreprises uniquement)
exports.updateStatutCandidature = async (req, res) => {
  try {
    const candidatureId = req.params.id;
    const { statut } = req.body;
    const entrepriseId = req.user.id;

    if (req.user.type_compte !== 'entreprise') {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    if (!['en_attente', 'acceptee', 'refusee'].includes(statut)) {
      return res.status(400).json({ error: 'Statut invalide.' });
    }

    // Vérifier que la candidature appartient à une offre de l'entreprise
    const [candidatures] = await db.query(
      `SELECT c.* FROM candidatures c
       JOIN offres o ON c.offre_id = o.id
       WHERE c.id = ? AND o.entreprise_id = ?`,
      [candidatureId, entrepriseId]
    );

    if (candidatures.length === 0) {
      return res.status(404).json({ error: 'Candidature non trouvée.' });
    }

    await db.query('UPDATE candidatures SET statut = ? WHERE id = ?', [statut, candidatureId]);

    res.json({ message: 'Statut mis à jour avec succès !' });

  } catch (error) {
    console.error('Erreur lors de la mise à jour:', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
};